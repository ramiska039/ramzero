<?PHP
//кошелек payeer
$accountNumber = 'P123456';
//api id payeer
$apiId = '123456';
//api секретный ключ
$apiKey = '123456';



//id магазина
$payeerShopId = '123456';
//ключ магазина
$payeerShopKey = '123456';
?>