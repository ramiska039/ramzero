<? echo $banner_content ?>

<div class="footer"> 
<table align="center" style="margin: 0 auto;">
<tr>
<td>
<a style="color:#ffffff; text-decoration: none;" href="/"><? echo $site_title_footer ?> © <? echo date('Y') ?></a>
</td>
<td>
<a href="//www.free-kassa.ru/" target="_blank"><img src="/img/13.png"></a>
</td>

<td>
<a href="https://payeer.com/?partner=172824" target="_blank"><img src="/img/payeer_b.png"></a>
</td>

<td>


<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter -->

<!-- /Yandex.Metrika counter -->

</td>



</tr>
</table>
</div>
</div><!--wrapper end-->



<!-- счетчик онлайн (amung.us) -->

<!-- /счетчик онлайн (amung.us) -->

</body>
</html>	